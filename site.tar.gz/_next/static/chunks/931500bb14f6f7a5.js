__turbopack_load_page_chunks__("/_error", [
  "static/chunks/17722e3ac4e00587.js",
  "static/chunks/63cc76cac4f76171.js",
  "static/chunks/turbopack-a824fb7e38e439dd.js"
])
