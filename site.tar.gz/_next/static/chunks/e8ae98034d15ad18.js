__turbopack_load_page_chunks__("/_app", [
  "static/chunks/e60ef129113f6e24.js",
  "static/chunks/63cc76cac4f76171.js",
  "static/chunks/turbopack-c133b1a453291372.js"
])
